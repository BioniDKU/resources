# SuwakoDebloater - UWP-based system components installer subscript - (c) Bionic Butter

Param(
	[Parameter(Mandatory=$true,Position=0)]
	[int32]$pkgno
)

. $PSScriptRoot\Show-Branding.ps1
function Add-ThePackage($pkgno) {
	switch ($pkgno) {
		0 {$msix = "AppInstaller"; $depx = "0"}
		1 {$msix = "WindowsStore"; $depx = "1"}
		2 {$msix = "WindowsNotepad"; $depx = "1"}
	}
	$tries = 0
	while ($tries -le 3) {
		try {Add-AppxPackage -Path "$PSScriptRoot\..\Packages\$msix\*.msixbundle" -ErrorAction Stop; break}
		catch {Add-AppxPackage -Path "$PSScriptRoot\..\Packages\Dependencies\$depx*.appx"; $tries++}
	}
}
Show-Branding 2

switch ($pkgno) {
	0 {$descr = "App Installer version 2023.118.406.0"}
	1 {$descr = "Microsoft Store version 22301.1401.15.0 (which has the Windows 11 UI)"}
	2 {$descr = "Notepad version 10.2003.0.0 (which looks like the Windows 10 one except with the new icon)"}
}
Write-Host -ForegroundColor White "This will install ${descr}."
Write-Host -ForegroundColor White "Please note that this will ONLY install to the current user. If you have system-wide-debloated using this same app and want to get this on other users, you must run this again on each of them."
Write-Host "During the installation errors may occur. For most cases this should be normal as the app will try to verify if the dependencies are installed first. If the app didn't get installed, collect the errors and contact me.`r`n"

Write-Host -ForegroundColor Yellow "Process with the installation? Yes to continue or anything else to close the window."
Write-Host "> " -n; $installfirm = Read-Host

if ($installfirm -notlike "yes") {exit}

Write-Host -ForegroundColor Black -BackgroundColor Yellow "Starting the installation..."
Add-ThePackage $pkgno

Write-Host -ForegroundColor Black -BackgroundColor Green "INSTALLATION PROCESS FINISHED" -n; Write-Host " (hopefully successfully)"