# SuwakoDebloater - The debloat script - (c) Bionic Butter

Param(
	[Parameter(Mandatory=$true,Position=0)]
	[bool]$removcusr,
	[Parameter(Mandatory=$true,Position=1)]
	[bool]$removausr,
	[Parameter(Mandatory=$true,Position=2)]
	[bool]$removprov,
	[Parameter(Mandatory=$true,Position=3)]
	[bool]$removstor
)

. $PSScriptRoot\NoList.ps1
if (-not $removstor) {$nein += "Microsoft.WindowsStore"}
$no += $nein

switch ($true) {
	$removcusr {Write-Host -ForegroundColor Cyan -BackgroundColor DarkGray "Removing current user's UWP apps..."; Get-AppxPackage | Where-Object {$no -notcontains [string]$_.name} | Remove-AppxPackage -ErrorAction SilentlyContinue}
	$removcusr {Write-Host -ForegroundColor Cyan -BackgroundColor DarkGray "Removing all users' UWP apps..."; Get-AppxPackage -AllUsers | Where-Object {$no -notcontains [string]$_.name} | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue}
	$removprov {
		Write-Host -ForegroundColor Cyan -BackgroundColor DarkGray "Removing preloaded UWP apps..."
		try {
			Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Where-Object {$nein -notcontains [string]$_.displayname} | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue
			break
		} catch {$tries++; if ($tries -gt 7) {break}}
	}
}
