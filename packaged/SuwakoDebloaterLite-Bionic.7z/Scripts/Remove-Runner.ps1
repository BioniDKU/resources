# SuwakoDebloater - Subscripts runner - (c) Bionic Butter

Param(
	[Parameter(Mandatory=$true,Position=0)]
	[bool]$removcusr,
	[Parameter(Mandatory=$true,Position=1)]
	[bool]$removausr,
	[Parameter(Mandatory=$true,Position=2)]
	[bool]$removprov,
	[Parameter(Mandatory=$true,Position=3)]
	[bool]$removstor,
	[Parameter(Mandatory=$true,Position=4)]
	[bool]$edgeaveyo,
	[Parameter(Mandatory=$true,Position=5)]
	[bool]$edwvaveyo
)

. $PSScriptRoot\Show-Branding.ps1
function Show-NotifyBalloon($title,$message) {
	[system.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
	$Global:Balloon = New-Object System.Windows.Forms.NotifyIcon
	$Balloon.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon((Get-Process -id $pid | Select-Object -ExpandProperty Path))
	$Balloon.BalloonTipText = $message
	$Balloon.BalloonTipTitle = $title
	$Balloon.Visible = $true
	$Balloon.ShowBalloonTip(1000)
}
Show-Branding 1

Write-Host -ForegroundColor Black -BackgroundColor Red "Starting the removal process in 5 seconds..."
Start-Sleep -Seconds 5

if ($removcusr -or $removausr) {$removxusr = $true}
switch ($true) {
	{$removcusr -or $removausr -or $removprov} {& $PSScriptRoot\Remove-AllApps.ps1 $removcusr $removausr $removprov $removstor}
	$edgeaveyo {& $PSScriptRoot\Remove-EdgeAveYo.ps1 $edwvaveyo $removxusr}
}

Write-Host -ForegroundColor Black -BackgroundColor Green "REMOVAL PROCESS COMPLETED!"
Show-NotifyBalloon "Debloating process completed!" "You can return to the tool."
Start-Sleep -Seconds 7
$Balloon.Visible = $false
Write-Host -ForegroundColor Black -BackgroundColor White "Press Enter to close this window."
