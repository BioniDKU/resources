# SuwakoDebloater - (c) Bionic Butter

function Show-Disenabled($value) {
	if ($value) {
		Write-Host -ForegroundColor Green " (ENABLED)"
	} else {
		Write-Host -ForegroundColor Red " (DISABLED)"
	}
}
function Select-Disenabled($value) {
	if ($value) {
		return $false
	} else {
		return $true
	}
}

function Remove-AllApps {
	Show-Branding 1
	Write-Host -ForegroundColor Black -BackgroundColor Yellow "BE CAREFUL! THIS MAY DAMAGE YOUR SYSTEM!"
	Write-Host -ForegroundColor Yellow "This will remove EVERY, SINGLE, EXISTING (user installed and preinstalled) UWP APP POSSIBLE, SYSTEM WIDE, from your device (except those you specified in the options, and a few exclusions)."
	if ($edgeaveyo) {
		Write-Host -ForegroundColor Yellow "In addition, Edge and its components (except those you specified to not remove) will also be removed. This requires quitting Explorer, so please save your work in all opening Explorer windows before continuing."
		$aftertext = "Explorer is restarted."
	} else {$aftertext = "a notification is sent."}
	Write-Host " " 
	Write-Host -ForegroundColor White "The removal process will spit out of errors, and that is normal."
	Write-Host -ForegroundColor White "In addition, as it proceeds PowerShell will display a console HUD that flashes repeatedly. If you are sensitive to flashes, please minimize or do not look at this window until $aftertext"
	Write-Host " " 
	Write-Host -ForegroundColor Yellow "Do you wish to purge them all? Yes to continue or anything else to go back."
	Write-Host "> " -n; $removefirm = Read-Host
	
	if ($removefirm -like "yes") {
		Show-Branding 1
		Write-Host "Removal in progress..." -ForegroundColor Cyan -BackgroundColor DarkGray
		$removearg = "-ExecutionPolicy Unrestricted `"& $PSScriptRoot\Scripts\Remove-Runner.ps1 %{0} %{1} %{2} %{3} %{4} %{5}; Read-Host`"" -f $removcusr,$removausr,$removprov,$removstor,$edgeaveyo,$edwvaveyo
		Start-Process powershell -Wait -ArgumentList $removearg.replace("%","$")
	}
}
function Start-InstallSC($pkgno) {
	Start-Process powershell -ArgumentList "-ExecutionPolicy Unrestricted `"& $PSScriptRoot\Scripts\Reinstall-StoreComponents.ps1 $pkgno; Write-Host -ForegroundColor Black -BackgroundColor White `"Press Enter close this window.`"; Read-Host`""
}
function Set-RemoveOptions {
	while ($true) {
		Show-Branding 0
		if ($removausr) {$color1 = "DarkGray"} else {$color1 = "White"}
		Write-Host "Configure what to remove in the debloating process:" -ForegroundColor Cyan
		Write-Host -ForegroundColor $color1 "1. Remove ALL installed UWPs from the current user" -n; if ($removausr) {Write-Host -ForegroundColor DarkGray " (ENABLED, all users means the current user also)"} else {Show-Disenabled $removcusr}
		Write-Host -ForegroundColor White "2. Remove ALL installed UWPs from ALL users" -n; Show-Disenabled $removausr
		Write-Host -ForegroundColor White "3. Remove ALL preloaded UWPs from the system *" -n; Show-Disenabled $removprov
		if ($removcusr -or $removausr -or $removprov) {Write-Host -ForegroundColor White "4. Remove the Microsoft Store as well" -n; Show-Disenabled $removstor}
		Write-Host -ForegroundColor White "5. Remove Microsoft Edge (using AveYo's script)" -n; Show-Disenabled $edgeaveyo
		if ($edgeaveyo) {Write-Host -ForegroundColor White "6. Remove Microsoft Edge WebView also" -n; Show-Disenabled $edwvaveyo}
		Write-Host -ForegroundColor White "0. Return to main menu`r`n"
		Write-Host " * (These apps gets installed when a new user is created)"
		Write-Host "> " -n ; $cho = Read-Host
		switch ($cho) {
			"1" {$global:removcusr = Select-Disenabled $removcusr}
			"2" {$global:removausr = Select-Disenabled $removausr; $global:removcusr = $true}
			"3" {$global:removprov = Select-Disenabled $removprov}
			"4" {if ($removcusr -or $removausr -or $removprov) {$global:removstor = Select-Disenabled $removstor}}
			"5" {$global:edgeaveyo = Select-Disenabled $edgeaveyo}
			"6" {if ($edgeaveyo) {$global:edwvaveyo = Select-Disenabled $edwvaveyo}}
			"0" {return}
		}
	}
}
function Install-SysComps {
	while ($true) {
		Show-Branding 2
		if (-not $amd64) {Write-Host -ForegroundColor Black -BackgroundColor Yellow "WARNING"; Write-Host " - Currently dependencies for these packages are only available for the AMD64 architecture. You can use these options if you are sure you didn't have the dependencies removed via a debloat." -ForegroundColor Red}
		if ($build -lt 17763) {$colorA = "DarkGray"} else {$colorA = "White"}
		if ($build -lt 18363) {$colorS = "DarkGray"} else {$colorS = "White"}
		if ($build -lt 19541) {$colorN = "DarkGray"} else {$colorN = "White"}
		Write-Host "Select an action" -ForegroundColor Cyan
		Write-Host "1. Install Microsoft Store" -ForegroundColor $colorS -n; Write-Host " (18363+)"
		Write-Host "2. Install App Installer" -ForegroundColor $colorA -n; Write-Host " (17763+)"
		Write-Host "3. Install Notepad" -ForegroundColor $colorN -n; Write-Host " (19541+)"
		Write-Host "0. Return to the main menu" -ForegroundColor White
		Write-Host " "
		Write-Host "> " -n; $sel = Read-Host
		switch ($sel) {
			{$_ -like "1"} {if ($colorS -like "White") {Start-InstallSC 1}}
			{$_ -like "2"} {if ($colorA -like "White") {Start-InstallSC 0}}
			{$_ -like "3"} {if ($colorN -like "White") {Start-InstallSC 2}}
			{$_ -like "0"} {return}
		}
	}
}

$elevator = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$elevated = $elevator.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$global:build = [System.Environment]::OSVersion.Version | Select-Object -ExpandProperty "Build"
$global:amd64 = [Environment]::Is64BitOperatingSystem

. $PSScriptRoot\Scripts\Show-Branding.ps1
$global:removcusr = $true
$global:removausr = $true
$global:removprov = $true
$global:removstor = $true
$global:edgeaveyo = $true
$global:edwvaveyo = $true
if (-not (Test-Path -Path $PSScriptRoot\Packages)) {$unlite = $false} else {$unlite = $true}

while ($true) {
	if (-not $elevated) {$color1 = "DarkGray"; $snars1 = " - Please relaunch this tool as Administrator to use the debloat function."}
	elseif (-not $removcusr -and -not $removausr -and -not $removprov -and -not $edgeaveyo) {$color1 = "DarkGray"; $snars1 = " - Select at least one debloating option to to use the debloat function."}
	else {$color1 = "White"; $snars1 = $null}
	
	Show-Branding 0
	if ($color1 -like "DarkGray") {Write-Host -ForegroundColor Black -BackgroundColor Red "Some functionalities are currently disabled"; Write-Host "${snars1}`r`n" -ForegroundColor Red}
	Write-Host "What do you want to do?" -ForegroundColor Cyan
	Write-Host "1. Debloat the system" -ForegroundColor $color1
	Write-Host "2. Adjust debloating options" -ForegroundColor $color1
	if ($unlite) {Write-Host "3. (Re)install system components" -ForegroundColor White}
	Write-Host "0. Exit this program" -ForegroundColor White
	Write-Host " "
	Write-Host "> " -n; $sel = Read-Host
	switch ($sel) {
		{$_ -like "1" -and $color1 -like "White"} {Remove-AllApps}
		{$_ -like "2" -and $color1 -like "White"} {Set-RemoveOptions}
		{$_ -like "3" -and $unlite} {Install-SysComps}
		{$_ -like "0"} {exit}
	}
}
